%% MCU init file
%% Initilization
% Basic functions
clc
clear all

%% Experiementation initization
FPWM = 20e3;                % Hz    // PWM fequency
Tm = 0.5e-6;                %s      // Dead Time
Ts = 1e-4;                  %s      // Sampling period

%% Motor Parameters
motor.model    = 'Teknic-2310P';                    %           // Manufacturer Model Number
motor.sn       = '003';                             %           // Manufacturer Model Number
motor.p        = 4;                                 %           // Pole Pairs for the motor
motor.R        = 0.656;                             % Ohm       // Stator Resistor
motor.L        = 0.35e-3;                           % H         // Inductance value
motor.Phif     = 6.6e-3;                            % Wb        // PM flux 
motor.J        = 1e-05;                             % Kg-m2     // Inertia in SI units
motor.F        = 1.e-05;                            % Kg-m2/s   // Friction Co-efficient
motor.C0       = 0.01;                              % Kg-m2     // Dry friction
motor.omegaMax    = 350;                            % rad/s     // Max speed
motor.vDC = 24;                                     % V         // DC voltage
motor.iMax = 4.4;                                % A       	// Rated current (phase-peak)

%% Math tools
math.J = [0 -1;1 0];                                % rotation matrix with angle pi/2

%% Controller Parameters
control.kElec = [0.262400000000000,-1.229531428571429e+03];
control.kMeca = [0.025000000000000,-0.631313131313132];